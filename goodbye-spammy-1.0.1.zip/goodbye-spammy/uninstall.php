<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
delete_option( 'nrw_gs_options' );
delete_option( 'nrw_gs_stats' );
delete_option( 'nrw_gs_stats_last' );
delete_option( 'nrw_gs_ai_last_error' );
delete_transient( 'nrw_gs_github_release' );
delete_transient( 'nrw_gs_test_result' );
wp_clear_scheduled_hook( 'nrw_gs_daily_cleanup' );
